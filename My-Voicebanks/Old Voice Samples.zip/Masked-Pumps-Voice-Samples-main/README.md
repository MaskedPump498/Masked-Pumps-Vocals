# Masked-Pumps-Voicebanks
all of my voicebanks or samples idk what to call it

have fun using them , i guess 

I DID NOT MAKE ANY OF THESE MODS , ALL CREDITS GOES TO ORIGINAL MODS CREATORS
